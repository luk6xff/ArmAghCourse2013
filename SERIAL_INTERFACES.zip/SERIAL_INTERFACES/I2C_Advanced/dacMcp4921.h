void DAC_MCP4921_Set_Adv(unsigned int uiData);
void DAC_MCP4921_Init(void);


