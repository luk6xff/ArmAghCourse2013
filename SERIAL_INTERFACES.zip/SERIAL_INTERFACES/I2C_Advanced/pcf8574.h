void PCF8574_Init(void);


void PCF8574_Write(unsigned char ucData);


void PCF8574_Read(void);

