void I2C_Init(void);
void PCF8574_Write(unsigned char ucData);

