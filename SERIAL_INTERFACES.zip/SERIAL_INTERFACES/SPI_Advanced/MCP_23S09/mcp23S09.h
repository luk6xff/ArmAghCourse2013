void MCP23S09_Init(void);

void Port_MCP23S09_Set(unsigned char ucData);
	
unsigned char Port_MCP23S09_Get(void);