
void DAC_MCP4921_Set(unsigned int uiVoltage);
